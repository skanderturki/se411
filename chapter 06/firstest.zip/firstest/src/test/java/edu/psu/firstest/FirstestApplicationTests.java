package edu.psu.firstest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstestApplicationTests {

	@Test
	void contextLoads() {
	}

}
