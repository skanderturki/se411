package edu.psu.firstest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstestApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstestApplication.class, args);
	}

}
